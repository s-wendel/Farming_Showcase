package shwendel.farming.crafting;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;

public class CraftingTableRightClickListener implements Listener {

    // TODO, Right clicking opens a list of recipes ?-
    @EventHandler
    public void playerInteract(PlayerInteractEvent event) {



    }

}
