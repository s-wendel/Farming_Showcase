package shwendel.farming.stats;

public enum YoggiesStatID {

    MANA,

    ;

}
