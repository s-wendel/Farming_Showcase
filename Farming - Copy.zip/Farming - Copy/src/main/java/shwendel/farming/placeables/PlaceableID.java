package shwendel.farming.placeables;

public enum PlaceableID {

    ,
    ;

}
