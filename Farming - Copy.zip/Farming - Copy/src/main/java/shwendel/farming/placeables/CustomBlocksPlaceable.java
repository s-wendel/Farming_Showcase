package shwendel.farming.placeables;

import shwendel.farming.item.YoggiesItem;

public interface CustomBlocksPlaceable {



}
