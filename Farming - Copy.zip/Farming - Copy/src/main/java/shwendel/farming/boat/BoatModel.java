package shwendel.farming.boat;

public interface BoatModel {

    int getBlocksPerSecondSpeed();
    int getManaCostPerSecond();

}
