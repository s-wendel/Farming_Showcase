package shwendel.farming.boat;

public class BoatMemory {

    // Flag design
    //private FlagMemory flag;
    // Boat decorations, e.g. vines hanging around the side ?
    //private List<BoatDecoration> boatDecorations;
    // Boat parts, mana motor, propellor
    //private List<BoatPartMemory>
    private String name;

}
