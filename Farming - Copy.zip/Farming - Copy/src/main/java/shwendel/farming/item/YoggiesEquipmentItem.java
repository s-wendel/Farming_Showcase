package shwendel.farming.item;

public abstract class YoggiesEquipmentItem extends YoggiesAbilityItem {

    @Override
    public boolean isStackable() {
        return false;
    }

}
