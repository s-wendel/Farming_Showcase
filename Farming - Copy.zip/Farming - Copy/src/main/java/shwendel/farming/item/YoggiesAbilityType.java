package shwendel.farming.item;

public enum YoggiesAbilityType {

    DAMAGE,
    RIGHT_CLICK,
    LEFT_CLICK,
    ;

}
