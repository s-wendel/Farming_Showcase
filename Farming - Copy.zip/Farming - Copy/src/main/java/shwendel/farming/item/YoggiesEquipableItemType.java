package shwendel.farming.item;

public enum YoggiesEquipableItemType {

    MAIN_HAND,
    OFF_HAND,
    HELMET,
    CHESTPLATE,
    LEGGINGS,
    BOOTS,
    EQUIPMENT,
    ;

}
