package shwendel.farming.item;

public enum YoggiesItemID {

    EQUIPMENT_BAG,
    NOTHING,
    HEALING_CHARM,
    WHEAT,
    WHEAT_SEEDS,
    CONVEYOR,
    RING_OF_NAMES,
    ;

}
