package shwendel.farming.item;

public class YoggiesAbilityItemMemory extends YoggiesItemMemory {

    public YoggiesAbilityItemMemory(YoggiesItem item) {
        super(item);
    }

}
