package shwendel.farming.soil;

public enum SoilID {

    MUDCRACKS,
    TEST,
    ;

}
