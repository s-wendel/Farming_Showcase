package shwendel.farming.custom_blocks;

public enum CustomBlockID {

    CONVEYOR

}
