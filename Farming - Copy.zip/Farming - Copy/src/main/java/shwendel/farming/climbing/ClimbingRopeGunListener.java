package shwendel.farming.climbing;


public class ClimbingRopeGunListener {

    /*@EventHandler
    public void playerInteract(PlayerInteractEvent event) {

        

    }*/

}
