package shwendel.farming.ores;

import org.joml.Vector3d;

public class OreModelBlockMemory {

    // D
    private Vector3d offsetFromOreModelCenter;

}
