package shwendel.farming.ores;

public enum OreSize {

    SMALL, // This is the variant of an ore that's just one block
    MEDIUM,
    LARGE,
    TITANIC

}
