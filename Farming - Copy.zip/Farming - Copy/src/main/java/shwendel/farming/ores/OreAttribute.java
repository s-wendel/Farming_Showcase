package shwendel.farming.ores;

public class OreAttribute {



}
