package shwendel.farming.ores;

public enum OreID {

    IRON,

    ;

}
