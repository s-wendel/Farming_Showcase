package shwendel.farming.spells;

// Siphon spells emit particles from an object that slowly travel back to the user
public abstract class AbstractSiphonSpell {

    public abstract int getRange();

}
