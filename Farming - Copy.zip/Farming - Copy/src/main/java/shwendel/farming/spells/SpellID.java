package shwendel.farming.spells;

public enum SpellID {

    ORE_GATHER,
    ORE_SPRINGTRAP
    ;

}
