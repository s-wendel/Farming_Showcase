package shwendel.farming.crops;

public enum CropID {

    WHEAT,
    ;

}
